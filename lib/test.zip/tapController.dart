import 'package:flutter/material.dart';

class TapController extends StatefulWidget {
  const TapController({Key key}) : super(key: key);

  @override
  _TapControllerState createState() => _TapControllerState();
}

class _TapControllerState extends State<TapController> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Center(
        child: Container(
          height: 50,
          color: Colors.white,
          child: TabBar(
            onTap: (index) {
              // Tab index when user select it, it start from zero
            },
            tabs: [
              Tab(
                child: Text(
                  "ปี 65/66",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ),
              Tab(
                child: Text(
                  "ปี 64/65",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ),
              Tab(
                child: Text(
                  "ปี 63/64",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ),
              Tab(
                child: Text(
                  "ปี 62/63",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ),
              Tab(
                child: Text(
                  "ปี 61/60",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
